This is the Sample for the **create-sling-composite** How-to in the Sling Site
